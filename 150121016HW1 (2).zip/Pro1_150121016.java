
public class Pro1_150121016 {

	public static void main(String[] args) {
		
		System.out.println("      ////////////////////////////////////");
		System.out.println("     ////////////////////////////////////");
		// These codes print hair.
		System.out.println("     |                                  |");
		System.out.println("     |     ^^^^^^           ^^^^^^      |                            ____                      ____");
		// This code prints eyebrows.
		System.out.println(" ____|      ____             ____       |_____      |    |  |       |          /\\     |\\   |  |      |\\  /|");
		System.out.println("|    |     |    |           |    |      |     |     |____|  |       |____     /  \\    | \\  |  |____  | \\/ |");
		System.out.println("|   _|     | 0  |           | 0  |      |_    |     |    |  |            |   /____\\   |  \\ |  |      |    |");
		System.out.println("|  | |     |____|           |____|      | |   |     |    |  |        ____|  /      \\  |   \\|  |____  |    |");
		System.out.println("|  | |                                  | |   |");
		System.out.println(" \\  \\|               /|                 |/   /");
		System.out.println("  \\__|              / |                 |   /       ______   ____             _____            ____   ____");
		System.out.println("     |             /  |                 |__/           |    |         /\\     |       |    |   |      |    |");
		System.out.println("     |            /___|                 |              |    |____    /  \\    |       |____|   |____  |____|");
		//these codes print eyes nose and ears.
		System.out.println("     |       ____________________       |              |    |       /____\\   |       |    |   |      |   \\ ");
		System.out.println("     |       \\| | | | | | | | |/        |              |    |____  /      \\  |_____  |    |   |____  |    \\");
		System.out.println("     |        \\_|_|_|_|_|_|_|_/         |");
		// These codes print mouth and teeth.
		System.out.println("      \\                                /                               HAVE A NİCE DAY");
		System.out.println("       \\                              /");
		System.out.println("        \\____________________________/");
		/*These codes print chin, 26th code prints text
		  Codes which are from 10th to 23th prints big massage. */


	}

}
